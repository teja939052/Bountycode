# Cehpoint Code - installer (Windows). Fully self-contained: fetches the engine if missing.
$ErrorActionPreference = 'Stop'
$dir = $PSScriptRoot
Write-Host ""
Write-Host "  Installing Cehpoint Code..." -ForegroundColor Cyan

# 1) engine - auto-download (one-time) if not already present
$engineDir = Join-Path $env:LOCALAPPDATA 'CehpointCode\bin'
$engine    = Join-Path $engineDir 'cehpoint-code-engine.exe'
if (-not (Test-Path $engine)) {
  Write-Host "  Downloading the Cehpoint Code engine (one-time)..." -ForegroundColor Yellow
  New-Item -ItemType Directory -Force $engineDir | Out-Null
  $tmp = Join-Path $env:TEMP 'cehpoint-code-engine.zip'
  Remove-Item $tmp -Force -ErrorAction SilentlyContinue
  Invoke-WebRequest 'https://cehpoint.co.in/app/downloads/cehpoint-code-engine.zip' -OutFile $tmp -UseBasicParsing
  Expand-Archive $tmp -DestinationPath $engineDir -Force
  Remove-Item $tmp -Force -ErrorAction SilentlyContinue
  if (Test-Path $engine) { Write-Host "  + Engine installed." -ForegroundColor Green }
  else { Write-Host "  ! Engine download failed - check your connection and re-run." -ForegroundColor Red; exit 1 }
} else { Write-Host "  + Engine already present." }

# 2) add the launcher folder to the user's PATH
$p = [Environment]::GetEnvironmentVariable('Path','User')
if ($p -notlike "*$dir*") {
  [Environment]::SetEnvironmentVariable('Path', ($p.TrimEnd(';') + ';' + $dir), 'User')
  Write-Host "  + Added Cehpoint Code to your PATH."
} else { Write-Host "  + Already on PATH." }

# 3) configure the default keyless provider (Cehpoint AI, preconfigured, no key needed)
$env:JCODE_NO_UPDATE = '1'
'cehpoint' | & $engine provider add cehpoint --base-url 'https://ai.cehpoint.co.in/v1' --model 'cehpoint-ai' --api-key-stdin --overwrite | Out-Null
$st = Join-Path $env:USERPROFILE '.cehpoint-code-jc'
New-Item -ItemType Directory -Force $st | Out-Null
Set-Content (Join-Path $st 'active-provider') 'cehpoint'
Write-Host "  + Configured Cehpoint AI (free, keyless)." -ForegroundColor Green

Write-Host ""
Write-Host "  Done. Open a NEW terminal and run:" -ForegroundColor Green
Write-Host '    cehpoint-code "create a python script that backs up a folder"'
Write-Host "    cehpoint-code repl        (interactive)"
Write-Host "    cehpoint-code setup       (switch AI provider / key)"
Write-Host ""
