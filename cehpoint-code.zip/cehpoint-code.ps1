# Cehpoint Code - AI coding agent (fully branded engine).
# Preconfigured with the free Cehpoint AI API (keyless). Bring-your-own key or NVIDIA NIM optional.
$ErrorActionPreference = 'Stop'
$env:JCODE_NO_UPDATE = '1'; $env:JCODE_DISABLE_AUTO_UPDATE = '1'; $env:JCODE_AUTO_UPDATE = '0'

$ENGINE = Join-Path $env:LOCALAPPDATA 'CehpointCode\bin\cehpoint-code-engine.exe'
$STATE  = Join-Path $env:USERPROFILE '.cehpoint-code-jc'
$ACTIVE = Join-Path $STATE 'active-provider'
New-Item -ItemType Directory -Force -Path $STATE | Out-Null

function Banner {
  try { $Host.UI.RawUI.WindowTitle = 'Cehpoint Code' } catch {}
  Write-Host ""
  Write-Host "  +-------------------------------------------------+" -ForegroundColor DarkCyan
  Write-Host "  |                                                 |" -ForegroundColor DarkCyan
  Write-Host "  |   " -ForegroundColor DarkCyan -NoNewline; Write-Host "CEHPOINT CODE" -ForegroundColor Cyan -NoNewline; Write-Host "   AI coding agent            " -ForegroundColor Gray -NoNewline; Write-Host "|" -ForegroundColor DarkCyan
  Write-Host "  |   " -ForegroundColor DarkCyan -NoNewline; Write-Host "powered by Cehpoint AI" -ForegroundColor DarkGray -NoNewline; Write-Host "                        " -NoNewline; Write-Host "|" -ForegroundColor DarkCyan
  Write-Host "  |                                                 |" -ForegroundColor DarkCyan
  Write-Host "  +-------------------------------------------------+" -ForegroundColor DarkCyan
}
if (-not (Test-Path $ENGINE)) { Write-Host "[Cehpoint Code] engine not found at $ENGINE" -ForegroundColor Red; Write-Host "Run install.ps1 first." -ForegroundColor Yellow; exit 1 }

function AddProfile($url,$model,$key){ $key | & $ENGINE provider add cehpoint --base-url $url --model $model --api-key-stdin --overwrite | Out-Null }
function GetActive { if (Test-Path $ACTIVE) { (Get-Content $ACTIVE -Raw).Trim() } else { 'cehpoint' } }

function Setup {
  Banner; Write-Host ""
  Write-Host "  Choose the AI that powers Cehpoint Code:"
  Write-Host "    [1] Cehpoint AI      free, keyless, preconfigured           (recommended)" -ForegroundColor Green
  Write-Host "    [2] NVIDIA NIM       your NVIDIA API key (nvapi-...)"
  Write-Host "    [3] Bring your own   any OpenAI-compatible API"
  Write-Host ""
  switch ((Read-Host "  Enter 1-3").Trim()) {
    '2' { $k = Read-Host "  NVIDIA API key (nvapi-...)"; AddProfile 'https://integrate.api.nvidia.com/v1' 'deepseek-ai/deepseek-v4-pro' $k; Write-Host "  [ok] NVIDIA NIM." -ForegroundColor Green }
    '3' { $u=(Read-Host "  API base URL").Trim(); $m=(Read-Host "  Model").Trim(); $k=Read-Host "  API key"; AddProfile $u $m $k; Write-Host "  [ok] Your provider." -ForegroundColor Green }
    default { AddProfile 'https://ai.cehpoint.co.in/v1' 'cehpoint-ai' 'cehpoint'; Write-Host "  [ok] Cehpoint AI (free, keyless, preconfigured)." -ForegroundColor Green }
  }
  Set-Content -Path $ACTIVE -Value 'cehpoint' -Encoding utf8; Write-Host ""
}

$cmd = if ($args.Count -ge 1) { [string]$args[0] } else { '' }
if ($cmd -eq 'setup') { Setup; exit 0 }
if (-not (Test-Path $ACTIVE)) { Setup }

if ($cmd -eq 'help' -or $cmd -eq '--help' -or $cmd -eq '-h') {
  Banner
  Write-Host "  Provider: " -NoNewline; Write-Host (GetActive) -ForegroundColor Yellow
  Write-Host "  Usage:"
  Write-Host '    cehpoint-code                        launch the interactive agent'
  Write-Host '    cehpoint-code "your task here"      run a one-shot coding task'
  Write-Host "    cehpoint-code repl                   simple REPL (no full UI)"
  Write-Host "    cehpoint-code setup                  change the AI provider / key"
  Write-Host ""
  exit 0
}
# no args -> launch the full interactive agent (the branded TUI experience)
if ($cmd -eq '') { & $ENGINE --provider-profile (GetActive) --no-update; exit $LASTEXITCODE }
if ($cmd -eq 'repl') { & $ENGINE repl --provider-profile (GetActive) --no-update; exit $LASTEXITCODE }
& $ENGINE run @args --provider-profile (GetActive) --no-update --quiet
exit $LASTEXITCODE
