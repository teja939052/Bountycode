# Cehpoint Code

A branded AI coding agent for your terminal — describe a task in plain English and it builds it, or work interactively. Preconfigured with the **free Cehpoint AI API** (no key required). Bring your own API key or use NVIDIA NIM if you prefer.

## Install (Windows)

1. Download and extract the Cehpoint Code package.
2. Run the installer (it fetches the engine automatically — no other prerequisites):

```powershell
powershell -ExecutionPolicy Bypass -File install.ps1
```

3. Open a **new** terminal and run it.

## Usage

```
cehpoint-code "create a python script that renames files by date"   # one-shot task
cehpoint-code repl                                                  # interactive session
cehpoint-code setup                                                 # change the AI provider / key
```

## AI providers

Run `cehpoint-code setup` to choose:

| Option | What it uses |
|---|---|
| **Cehpoint AI** *(default)* | `https://ai.cehpoint.co.in/v1` — **free & keyless**, preconfigured. No API key needed; nothing is stored in this package. |
| **NVIDIA NIM** | `https://integrate.api.nvidia.com/v1` — your NVIDIA API key (`nvapi-...`). |
| **Bring your own** | Any OpenAI-compatible API (OpenAI, OpenRouter, DeepSeek, …). |

## Notes

- No secret is stored in this package — the default provider is keyless.
- The agent never auto-updates (the pinned engine is the source of truth).
