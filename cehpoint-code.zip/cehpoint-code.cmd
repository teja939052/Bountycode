@echo off
REM Cehpoint Code (jcode-based white-label) launcher.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0cehpoint-code.ps1" %*
